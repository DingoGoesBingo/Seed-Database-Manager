#!/bin/bash
cd "$(dirname "$0")"
Rscript runapp.R
